import java.util.Observable;
import java.util.Observer;

public class ConsoleView implements Observer {

	public void update(Observable arg0, Object status) {
		if ((Boolean) status) {
			System.out.println("I am happy :)");
		} else {
			System.out.println("I am sad :(");
		}
	}

}
