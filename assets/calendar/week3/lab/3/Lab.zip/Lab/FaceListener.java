import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class FaceListener implements ActionListener {
	
	private FaceStatus status;
	
	public FaceListener(FaceStatus status) {
		this.status = status;
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Be Happy!")) {
			status.beHappy();
		}
		else {
			status.beSad();
		}
	}

}










