import java.util.Observable;

public class FaceStatus extends Observable {
	private boolean happy = true;
	
	public void beHappy() {
		happy = true;
		setChanged();
		notifyObservers(happy);
	}
	
	public void beSad() {
		happy = false;
		setChanged();
		notifyObservers(happy);
	}
}







