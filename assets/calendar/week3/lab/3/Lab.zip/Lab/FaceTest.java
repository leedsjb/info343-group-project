import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * Demonstrate basic Java Swing graphics.
 */
public class FaceTest {

    /** Create a window with a smiley face inside it */
    public static void main(String[] args) {

        // create frame and give it a name
    	JFrame frame = new JFrame("A face");
    	frame.getContentPane().setBackground(Color.WHITE);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
        // The views
    	PanelView face = new PanelView();
    	frame.add(face, BorderLayout.CENTER); // Center not needed
    	// since it is the default
    	LabelView title = new LabelView("Happy", JLabel.CENTER);
    	frame.add(title, BorderLayout.NORTH);
    	ConsoleView consoleView = new ConsoleView();
    	
    	// the model of the face
    	FaceStatus status = new FaceStatus();
    	status.addObserver(face);
    	status.addObserver(title);
    	status.addObserver(consoleView);
    	
        // Add two buttons
    	JButton beHappy = new JButton("Be Happy!");
    	JButton beSad = new JButton("Be Sad!");
    	JPanel southPanel = new JPanel();
    	southPanel.setBackground(Color.WHITE);
    	southPanel.add(beHappy);
    	southPanel.add(beSad);
    	frame.add(southPanel, BorderLayout.SOUTH);
        // Program the buttons' clicks
    	FaceListener listener = new FaceListener(status);
    	beHappy.addActionListener(listener);
    	beSad.addActionListener(listener);
        // Set window size and display
    	frame.setSize(400, 400);
    	frame.setVisible(true);
    }
}






