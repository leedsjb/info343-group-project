import java.util.Observable;
import java.util.Observer;

import javax.swing.JLabel;

public class LabelView extends JLabel implements Observer {

	public LabelView(String title, int alignment) {
		super(title, alignment);
	}
	
	public void update(Observable arg0, Object status) {
		if ((Boolean) status) {
			setText("Happy");
		}
		else {
			setText("Sad");
		}
		repaint();
	}

}
